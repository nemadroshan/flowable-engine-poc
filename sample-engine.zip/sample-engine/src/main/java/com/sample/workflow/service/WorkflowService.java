package com.sample.workflow.service;


import com.sample.workflow.bean.WorkflowResponse;

public interface WorkflowService {
	
	public WorkflowResponse startProcess();
}
